import { Bounds, Point } from '../types';

export function getBase64FromImage(image: HTMLImageElement): string {
  const canvas = document.createElement('canvas');
  canvas.width = image.naturalWidth;
  canvas.height = image.naturalHeight;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(image, 0, 0);
  return canvas.toDataURL('image/png');
}

export function createMaskFromBounds(
  imageWidth: number,
  imageHeight: number,
  bounds: Bounds
): string {
  const canvas = document.createElement('canvas');
  canvas.width = imageWidth;
  canvas.height = imageHeight;
  const ctx = canvas.getContext('2d')!;

  // Fill with black (area to keep)
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, imageWidth, imageHeight);

  // Fill selection with white (area to replace)
  ctx.fillStyle = 'white';
  ctx.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);

  return canvas.toDataURL('image/png');
}


export function createMaskFromPolygon(
    imageWidth: number,
    imageHeight: number,
    polygon: Point[]
  ): string {
    const canvas = document.createElement('canvas');
    canvas.width = imageWidth;
    canvas.height = imageHeight;
    const ctx = canvas.getContext('2d')!;
  
    // Fill with black (area to keep)
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, imageWidth, imageHeight);
  
    // Fill polygon with white (area to replace)
    if (polygon.length > 2) {
      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.moveTo(polygon[0].x, polygon[0].y);
      for (let i = 1; i < polygon.length; i++) {
        ctx.lineTo(polygon[i].x, polygon[i].y);
      }
      ctx.closePath();
      ctx.fill();
    }
  
    return canvas.toDataURL('image/png');
  }

export function imageFromBase64(base64: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
        img.src = base64;
    });
}
