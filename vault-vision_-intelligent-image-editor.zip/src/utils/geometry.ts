export function getBoundsFromQuad(quad: { x: number; y: number }[]): { x: number; y: number; width: number; height: number } {
  if (!quad || quad.length < 1) {
    return { x: 0, y: 0, width: 0, height: 0 };
  }

  const xCoords = quad.map(p => p.x);
  const yCoords = quad.map(p => p.y);

  const minX = Math.min(...xCoords);
  const maxX = Math.max(...xCoords);
  const minY = Math.min(...yCoords);
  const maxY = Math.max(...yCoords);

  return {
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY,
  };
}
