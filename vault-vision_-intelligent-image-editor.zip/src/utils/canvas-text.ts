import { TextStyle, EnhancedTextRegion, Point } from '../types';

/**
 * Solves a system of linear equations for a 3x3 matrix to find the affine transform parameters.
 * [u]   [a b c] [x]
 * [v] = [d e f] [y]
 * [1]   [0 0 1] [1]
 * This is used to map a source triangle to a destination triangle.
 */
function getTriangleTransform(
  source: [Point, Point, Point],
  dest: [Point, Point, Point]
): { a: number; b: number; c: number; d: number; e: number; f: number } | null {
  const [s1, s2, s3] = source;
  const [d1, d2, d3] = dest;

  const A = [
    [s1.x, s1.y, 1, 0, 0, 0],
    [0, 0, 0, s1.x, s1.y, 1],
    [s2.x, s2.y, 1, 0, 0, 0],
    [0, 0, 0, s2.x, s2.y, 1],
    [s3.x, s3.y, 1, 0, 0, 0],
    [0, 0, 0, s3.x, s3.y, 1],
  ];

  const b = [d1.x, d1.y, d2.x, d2.y, d3.x, d3.y];

  // Solve Ax = b using Gaussian elimination
  const x = solve(A, b);
  if (!x) return null;

  return { a: x[0], b: x[1], c: x[2], d: x[3], e: x[4], f: x[5] };
}

// Basic Gaussian elimination solver
function solve(A: number[][], b: number[]): number[] | null {
  const n = A.length;
  for (let i = 0; i < n; i++) {
    let max = i;
    for (let j = i + 1; j < n; j++) {
      if (Math.abs(A[j][i]) > Math.abs(A[max][i])) {
        max = j;
      }
    }
    [A[i], A[max]] = [A[max], A[i]];
    [b[i], b[max]] = [b[max], b[i]];

    if (Math.abs(A[i][i]) <= 1e-10) return null; // No unique solution

    for (let j = i + 1; j < n; j++) {
      const ratio = A[j][i] / A[i][i];
      for (let k = i; k < n; k++) {
        A[j][k] -= ratio * A[i][k];
      }
      b[j] -= ratio * b[i];
    }
  }

  const x = new Array(n);
  for (let i = n - 1; i >= 0; i--) {
    let sum = 0;
    for (let j = i + 1; j < n; j++) {
      sum += A[i][j] * x[j];
    }
    x[i] = (b[i] - sum) / A[i][i];
  }
  return x;
}

/**
 * Renders text with perspective correction by mapping it onto a quadrilateral.
 * It first renders the styled text to an offscreen canvas, then draws that
 * canvas onto the main context, distorted to fit the target quad.
 */
export function renderEnhancedText(
  ctx: CanvasRenderingContext2D,
  text: string,
  region: EnhancedTextRegion,
  styleOverride?: Partial<TextStyle>
) {
  if (region.quad.length < 4) return;

  const style = { ...region.style, ...styleOverride };
  const { width, height } = region.bounds;
  if (width <= 0 || height <= 0) return;

  // 1. Create an offscreen canvas and render the text onto it without transformation.
  const offscreenCanvas = document.createElement('canvas');
  offscreenCanvas.width = width;
  offscreenCanvas.height = height;
  const octx = offscreenCanvas.getContext('2d')!;
  
  // Apply styles to offscreen canvas
  const font = `${style.fontStyle || 'normal'} ${style.fontWeight || 'normal'} ${style.fontSize}px ${style.fontFamily}`;
  octx.font = font;
  octx.fillStyle = style.color;
  octx.textBaseline = region.textBaseline || 'alphabetic';
  // FIX: The 'justify' value is valid in our TextStyle but not in CanvasTextAlign. Default to 'left'.
  const textAlign = style.textAlign || 'left';
  octx.textAlign = textAlign === 'justify' ? 'left' : textAlign;
  
  if (typeof (octx as any).letterSpacing === 'string') {
    (octx as any).letterSpacing = `${region.letterSpacing || 0}px`;
  }
  if (region.textShadow) {
    octx.shadowColor = region.textShadow.color;
    octx.shadowOffsetX = region.textShadow.offsetX;
    octx.shadowOffsetY = region.textShadow.offsetY;
    octx.shadowBlur = region.textShadow.blurRadius;
  }

  // Text rendering with pre-defined line breaks
  const lines = text.split('\n');
  const lineHeightPx = region.lineHeight * style.fontSize;
  
  const totalTextHeight = lines.length * lineHeightPx;
  let startY = (height - totalTextHeight) / 2; // Center vertically by default
  if (region.textBaseline === 'top') startY = 0;
  else if (region.textBaseline === 'bottom') startY = height - totalTextHeight;

  // Determine horizontal position based on justification
  let startX = 0;
  if (style.textAlign === 'center') {
      startX = width / 2;
  } else if (style.textAlign === 'right') {
      startX = width;
  }

  // Draw each line on the offscreen canvas
  lines.forEach((line, index) => {
    const yPos = startY + (index * lineHeightPx) + style.fontSize * 0.8; // Approximate baseline position
    octx.fillText(line, startX, yPos);
    if (region.textStroke && region.textStroke.width > 0) {
      octx.strokeStyle = region.textStroke.color;
      octx.lineWidth = region.textStroke.width;
      octx.strokeText(line, startX, yPos);
    }
  });

  // 2. Render the offscreen canvas onto the main context, distorted to fit the quad.
  const [tl, tr, br, bl] = region.quad;

  // Define source and destination triangles
  const srcTri1: [Point, Point, Point] = [{ x: 0, y: 0 }, { x: width, y: 0 }, { x: 0, y: height }];
  const dstTri1: [Point, Point, Point] = [tl, tr, bl];
  
  const srcTri2: [Point, Point, Point] = [{ x: width, y: 0 }, { x: width, y: height }, { x: 0, y: height }];
  const dstTri2: [Point, Point, Point] = [tr, br, bl];

  // Draw each triangle
  [ [srcTri1, dstTri1], [srcTri2, dstTri2] ].forEach(([src, dst]) => {
    ctx.save();
    
    // Clip to the destination triangle
    ctx.beginPath();
    ctx.moveTo(dst[0].x, dst[0].y);
    ctx.lineTo(dst[1].x, dst[1].y);
    ctx.lineTo(dst[2].x, dst[2].y);
    ctx.closePath();
    ctx.clip();

    // Calculate transformation matrix and apply it
    const transform = getTriangleTransform(src, dst);
    if (transform) {
      // setTransform args are: (m11, m21, m12, m22, dx, dy)
      // our transform is {a,b,c,d,e,f} corresponding to [a,b,c] for x and [d,e,f] for y
      // u = ax + by + c; v = dx + ey + f
      // This maps to setTransform(a, d, b, e, c, f)
      ctx.setTransform(transform.a, transform.d, transform.b, transform.e, transform.c, transform.f);
      ctx.drawImage(offscreenCanvas, 0, 0);
    }
    
    ctx.restore();
  });
}
