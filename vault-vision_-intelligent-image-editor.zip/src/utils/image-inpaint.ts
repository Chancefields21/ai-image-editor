import { OpenCVService } from '../services/opencv.service';

export async function applyInpaint(
  opencvService: OpenCVService,
  originalImage: HTMLImageElement,
  patchImage: HTMLImageElement,
  selectionBounds: { x: number; y: number; width: number; height: number }
): Promise<HTMLImageElement> {
  await opencvService.ensureLoaded();
  const cv = (window as any).cv;

  if (!cv) {
    throw new Error('OpenCV is not loaded.');
  }

  const dst = cv.imread(originalImage);
  const patch = cv.imread(patchImage);

  // Ensure patch has correct dimensions
  if (patch.cols !== selectionBounds.width || patch.rows !== selectionBounds.height) {
    const dsize = new cv.Size(selectionBounds.width, selectionBounds.height);
    cv.resize(patch, patch, dsize, 0, 0, cv.INTER_AREA);
  }

  // Define the region of interest (ROI) on the destination image
  const rect = new cv.Rect(selectionBounds.x, selectionBounds.y, selectionBounds.width, selectionBounds.height);
  const roi = dst.roi(rect);

  // If patch has an alpha channel, use it as a mask for seamless blending
  if (patch.channels() === 4) {
    const alpha = new cv.Mat();
    const rgbChannels = new cv.MatVector();
    cv.split(patch, rgbChannels);
    // The 4th channel is alpha
    const patchRgb = new cv.Mat();
    cv.merge([rgbChannels.get(0), rgbChannels.get(1), rgbChannels.get(2)], patchRgb);
    
    // Copy the patch to the ROI using the alpha channel as a mask
    patchRgb.copyTo(roi, rgbChannels.get(3));

    alpha.delete();
    rgbChannels.delete();
    patchRgb.delete();
  } else {
    // If no alpha, just copy it directly
    patch.copyTo(roi);
  }

  const resultCanvas = document.createElement('canvas');
  resultCanvas.width = originalImage.naturalWidth;
  resultCanvas.height = originalImage.naturalHeight;
  cv.imshow(resultCanvas, dst);

  // Clean up OpenCV mats
  dst.delete();
  patch.delete();
  roi.delete();

  // Convert canvas to image
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = (err) => reject(err);
    image.src = resultCanvas.toDataURL('image/png');
  });
}
