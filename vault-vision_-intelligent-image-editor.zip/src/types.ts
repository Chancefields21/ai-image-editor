export type ToolType =
  | 'selection'
  | 'crop'
  | 'brush'
  | 'text'
  | 'object-removal'
  | 'upscale'
  | 'content-to-path'
  | 'image-generation';

export interface Point {
  x: number;
  y: number;
}

export interface Bounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface TextStyle {
  color: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: string;
  fontStyle: string;
  rotation: number;
  textAlign?: 'left' | 'center' | 'right' | 'justify';
}

export interface TextRegion {
  id: string;
  text: string;
  quad: Point[];
  bounds: Bounds;
  style: TextStyle;
  confidence: number;
}

export type TextBaseline = 'top' | 'hanging' | 'middle' | 'alphabetic' | 'ideographic' | 'bottom';

export interface TextShadow {
  color: string;
  offsetX: number;
  offsetY: number;
  blurRadius: number;
}

export interface TextStroke {
  color: string;
  width: number;
}

export interface GradientStop {
  color: string;
  offset: number; // 0 to 1
}

export interface GradientInfo {
  type: 'linear' | 'radial';
  stops: GradientStop[];
  angle?: number; // in degrees
  center?: Point;
  radius?: number;
}

export interface EnhancedTextRegion extends TextRegion {
  textBaseline: TextBaseline;
  letterSpacing: number; // in pixels
  lineHeight: number; // multiplier of font size
  textShadow?: TextShadow;
  textStroke?: TextStroke;
  backgroundGradient?: GradientInfo;
  contextualHints: string[];
  semanticRole: 'heading' | 'body' | 'caption' | 'logo' | 'decorative';
}

export interface Layer {
  id: string;
  name: string;
  image: HTMLImageElement;
  thumbnail: string;
  isVisible: boolean;
  opacity: number; // 0-1
  blendMode: GlobalCompositeOperation;
}

export interface SelectionState {
  isSelecting: boolean;
  startPoint?: Point;
  endPoint?: Point;
}

export interface TextEditConfig {
  detectedRegions: EnhancedTextRegion[];
  selectedRegion: EnhancedTextRegion | null;
  originalText: string;
  newText: string;
  preserveStyle: boolean;
  customStyle: TextStyle;
}

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
}

export interface MenuItem {
  label: string;
  shortcut?: string;
  separator?: boolean;
  action?: () => void;
  items?: MenuItem[]; // For submenus
  disabled?: boolean;
}

// === New types for Advanced Text Editor Panel ===

export interface VariableAxis {
  tag: string;
  name: string;
  min: number;
  max: number;
  defaultValue: number;
}

export type TextEffect = 'glow' | 'outline' | 'emboss' | 'bevel' | 'gradient';

export type BlendingMode =
  | 'normal'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten'
  | 'color-dodge'
  | 'color-burn'
  | 'hard-light'
  | 'soft-light'
  | 'difference'
  | 'exclusion'
  | 'hue'
  | 'saturation'
  | 'color'
  | 'luminosity';

export type MaskOption = 'vector-mask' | 'raster-mask' | 'clipping-path';

export interface TextEditorPanelConfig {
  panels: {
    quickEdit: {
      inlineTextInput: boolean;
      realtimePreview: boolean;
      smartSuggestions: boolean;
    };
    advancedTypography: {
      openTypeFeatures: string[];
      variableFontAxes: VariableAxis[];
      customLigatures: boolean;
      contextualAlternates: boolean;
    };
    effectsStudio: {
      textEffects: TextEffect[];
      blendingModes: BlendingMode[];
      maskingOptions: MaskOption[];
    };
    aiAssistant: {
      styleMatching: boolean;
      contextualSuggestions: boolean;
      grammarCheck: boolean;
      toneAdjustment: boolean;
    };
  };
}

export interface OptimalTextParams {
  optimalText: string; // Text with appropriate line breaks ('\n')
  optimalStyle: Partial<Pick<TextStyle, 'fontSize'>>; // e.g., adjusted fontSize
  justification: 'left' | 'center' | 'right';
}


// === New types for Effects Studio ===

export interface DropShadowEffect {
  type: 'drop-shadow';
  color: string;
  offsetX: number;
  offsetY: number;
  blur: number;
}

export interface GlowEffect {
  type: 'glow';
  color: string;
  blur: number;
  intensity: number; // 0-1
}

export type Effect = DropShadowEffect | GlowEffect;