import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * This component is currently not used.
 * Stubbed to resolve potential compilation errors.
 */
@Component({
  selector: 'app-stroke-dialog',
  standalone: true,
  imports: [CommonModule],
  template: ``,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class StrokeDialogComponent {}
