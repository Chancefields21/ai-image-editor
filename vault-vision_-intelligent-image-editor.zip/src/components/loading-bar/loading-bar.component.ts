import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoadingStateService } from '../../services/loading-state.service';

@Component({
  selector: 'app-loading-bar',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (isLoading()) {
      <div 
        class="fixed inset-0 bg-black/50 z-40" 
        aria-hidden="true">
      </div>
      <div 
        class="fixed top-0 left-0 right-0 h-1 z-50 bg-indigo-500/20 overflow-hidden"
        role="progressbar"
        aria-valuemin="0"
        aria-valuemax="100"
        aria-label="Loading indicator"
        >
        <div class="w-full h-full bg-indigo-500 animate-loading-bar"></div>
      </div>
      <div class="fixed bottom-4 left-1/2 -translate-x-1/2 bg-gray-800 border border-gray-600 text-white px-4 py-2 rounded-md shadow-lg z-50">
        {{ loadingMessage() }}
      </div>
    }
  `,
  styles: [`
    @keyframes loading-bar-animation {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
    }
    .animate-loading-bar {
        animation: loading-bar-animation 1.5s ease-in-out infinite;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoadingBarComponent {
  private loadingState = inject(LoadingStateService);
  isLoading = this.loadingState.isLoading;
  loadingMessage = this.loadingState.loadingMessage;
}
