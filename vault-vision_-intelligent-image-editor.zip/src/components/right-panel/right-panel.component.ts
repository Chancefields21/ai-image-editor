import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EditorStateService } from '../../services/editor-state.service';
import { DropShadowEffect, GlowEffect } from '../../types';

@Component({
  selector: 'app-right-panel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="w-80 bg-[var(--charcoal-bg)] h-full flex flex-col border-l border-[var(--border-color)] p-4 space-y-4">
      
      @if (activeTool() === 'text') {
        <div class="bg-black/20 rounded-lg border border-[var(--border-color)] flex flex-col h-full">
            <header class="flex items-center justify-between p-3 border-b border-[var(--border-color)] shrink-0">
                <h3 class="font-semibold">Text Editor</h3>
                @if (selectedRegion()) {
                <button (click)="unselectRegion()" class="text-gray-400 hover:text-white" title="Unselect region">&times;</button>
                }
            </header>

            @if (selectedRegion(); as region) {
                <div class="p-3 space-y-4 overflow-y-auto custom-scrollbar flex-grow">
                  <div>
                      <label for="text-input" class="text-sm font-medium text-gray-400 block mb-1">Replacement Text</label>
                      <textarea 
                      id="text-input"
                      [ngModel]="textConfig().newText"
                      (ngModelChange)="updateNewText($event)"
                      rows="3"
                      class="bg-black/30 border border-[var(--border-color)] rounded-md p-2 w-full text-sm placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-[var(--gold-text)]"
                      placeholder="Enter new text here..."
                      ></textarea>
                  </div>

                  <div class="pt-2">
                      <button 
                      (click)="applyChanges()"
                      class="w-full text-black font-semibold py-2 px-4 rounded-md transition-opacity hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                      [style.background]="canApply() ? 'var(--gold-gradient)' : '#4b5563'"
                      [disabled]="!canApply()"
                      >
                      Apply as New Layer
                      </button>
                  </div>

                  <details class="text-sm pt-2">
                      <summary class="cursor-pointer text-gray-400 hover:text-white">Detected Properties</summary>
                      <div class="mt-2 p-3 bg-black/20 rounded-md space-y-1 text-xs">
                          <p><strong class="text-gray-400 w-20 inline-block">Font:</strong> {{ region.style.fontFamily }} ({{ region.style.fontSize }}px)</p>
                          <p><strong class="text-gray-400 w-20 inline-block">Color:</strong> <span class="inline-block w-3 h-3 rounded-sm border border-white/20" [style.background]="region.style.color"></span> {{ region.style.color }}</p>
                          <p><strong class="text-gray-400 w-20 inline-block">Role:</strong> {{ region.semanticRole }}</p>
                          <p><strong class="text-gray-400 w-20 inline-block">Confidence:</strong> {{ (region.confidence * 100).toFixed(1) }}%</p>
                          @if(region.textShadow) {
                            <p><strong class="text-gray-400 w-20 inline-block">Shadow:</strong> Yes</p>
                          }
                           @if(region.textStroke) {
                            <p><strong class="text-gray-400 w-20 inline-block">Stroke:</strong> Yes</p>
                          }
                      </div>
                  </details>
                </div>
            } @else {
                <div class="p-4 text-center text-sm text-gray-500 flex-grow flex items-center justify-center">
                  <p>Select a text region on the canvas to begin editing.</p>
                </div>
            }
        </div>
      } @else if (activeTool() === 'image-generation') {
        <!-- Image Generation Panel -->
        <div class="bg-black/20 rounded-lg border border-[var(--border-color)] flex flex-col h-full">
            <header class="flex items-center justify-between p-3 border-b border-[var(--border-color)] shrink-0">
                <h3 class="font-semibold">AI Image Generation</h3>
            </header>
            <div class="p-3 space-y-4 overflow-y-auto custom-scrollbar flex-grow">
              <div>
                  <label for="image-prompt" class="text-sm font-medium text-gray-400 block mb-1">Prompt</label>
                  <textarea 
                  id="image-prompt"
                  [ngModel]="imageGenPrompt()"
                  (ngModelChange)="imageGenPrompt.set($event)"
                  rows="4"
                  class="bg-black/30 border border-[var(--border-color)] rounded-md p-2 w-full text-sm placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-[var(--gold-text)]"
                  placeholder="A photorealistic image of..."
                  ></textarea>
              </div>
              <div>
                <label for="aspect-ratio" class="text-sm font-medium text-gray-400 block mb-1">Aspect Ratio</label>
                <div class="grid grid-cols-5 gap-2">
                  @for(ratio of aspectRatios; track ratio.value) {
                    <button 
                      (click)="imageGenAspectRatio.set(ratio.value)"
                      class="p-2 rounded-md text-xs border transition-colors"
                      [class]="imageGenAspectRatio() === ratio.value ? 'bg-amber-400/20 border-amber-400 text-amber-300' : 'bg-black/20 border-gray-600 hover:border-gray-400 text-gray-400'">
                      {{ ratio.label }}
                    </button>
                  }
                </div>
              </div>
              <div class="pt-2">
                  <button 
                  (click)="generateImage()"
                  class="w-full text-black font-semibold py-2 px-4 rounded-md transition-opacity hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
                  [style.background]="imageGenPrompt().trim() ? 'var(--gold-gradient)' : '#4b5563'"
                  [disabled]="!imageGenPrompt().trim()"
                  >
                  Generate Image
                  </button>
              </div>
            </div>
        </div>
      } @else {
        <!-- Layers Panel -->
        <div class="bg-black/20 rounded-lg border border-[var(--border-color)]">
          <header class="flex items-center justify-between p-3 border-b border-[var(--border-color)]">
            <h3 class="font-semibold">Layers</h3>
            <button class="text-gray-500 hover:text-white">&plus;</button>
          </header>
          <div class="p-3 space-y-3">
              <ul class="space-y-1">
                @for(layer of layers().slice().reverse(); track layer.id) {
                  <li 
                    (click)="selectLayer(layer.id)"
                    class="flex items-center gap-2 p-1.5 rounded-md cursor-pointer transition-all"
                    [class]="activeLayer()?.id === layer.id ? 'bg-white/10 ring-1 ring-amber-400' : 'bg-white/5 hover:bg-white/10'"
                    >
                    @if (layer.thumbnail) {
                      <img [src]="layer.thumbnail" class="w-10 h-10 object-contain rounded-sm bg-black/20"/>
                    }
                    <span class="text-sm truncate flex-grow">{{ layer.name }}</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-5 h-5 text-gray-400">
                      <path d="M10 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                      <path fill-rule="evenodd" d="M.664 10.59a1.651 1.651 0 0 1 0-1.186A10.004 10.004 0 0 1 10 3c4.257 0 7.893 2.66 9.336 6.41.147.381.146.804 0 1.186A10.004 10.004 0 0 1 10 17c-4.257 0-7.893-2.66-9.336-6.41ZM14 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z" clip-rule="evenodd" />
                    </svg>
                  </li>
                }
              </ul>
          </div>
        </div>

        <!-- Effects Studio Panel -->
        @if (activeLayer()) {
          <div class="bg-black/20 rounded-lg border border-[var(--border-color)]">
            <header class="flex items-center justify-between p-3 border-b border-[var(--border-color)]">
              <h3 class="font-semibold">Effects Studio</h3>
            </header>
            <div class="p-3 space-y-2 text-sm">
              <details class="[&_summary]:hover:bg-white/5 [&_summary]:p-2 [&_summary]:rounded-md" open>
                <summary class="cursor-pointer font-medium text-gray-300">Drop Shadow</summary>
                <div class="p-2 space-y-4">
                  <!-- Color -->
                  <div class="flex items-center justify-between">
                    <label for="ds-color" class="text-gray-400">Color</label>
                    <input id="ds-color" type="color" [ngModel]="dropShadowConfig().color" (ngModelChange)="updateDropShadow('color', $event)" class="w-8 h-8 p-0 border-none rounded cursor-pointer bg-transparent">
                  </div>
                  <!-- Offset X -->
                  <div class="space-y-1">
                    <label for="ds-offsetX" class="text-gray-400 flex justify-between"><span>Offset X</span> <span>{{ dropShadowConfig().offsetX }}px</span></label>
                    <input id="ds-offsetX" type="range" min="-50" max="50" [ngModel]="dropShadowConfig().offsetX" (ngModelChange)="updateDropShadow('offsetX', $event)" class="slider">
                  </div>
                  <!-- Offset Y -->
                  <div class="space-y-1">
                    <label for="ds-offsetY" class="text-gray-400 flex justify-between"><span>Offset Y</span> <span>{{ dropShadowConfig().offsetY }}px</span></label>
                    <input id="ds-offsetY" type="range" min="-50" max="50" [ngModel]="dropShadowConfig().offsetY" (ngModelChange)="updateDropShadow('offsetY', $event)" class="slider">
                  </div>
                  <!-- Blur -->
                  <div class="space-y-1">
                    <label for="ds-blur" class="text-gray-400 flex justify-between"><span>Blur</span> <span>{{ dropShadowConfig().blur }}px</span></label>
                    <input id="ds-blur" type="range" min="0" max="100" [ngModel]="dropShadowConfig().blur" (ngModelChange)="updateDropShadow('blur', $event)" class="slider">
                  </div>
                  <button (click)="applyDropShadow()" class="w-full text-black font-semibold py-2 px-4 rounded-md transition-opacity hover:opacity-90" style="background: var(--gold-gradient)">Apply</button>
                </div>
              </details>
              <hr class="border-[var(--border-color)]">
              <details class="[&_summary]:hover:bg-white/5 [&_summary]:p-2 [&_summary]:rounded-md">
                <summary class="cursor-pointer font-medium text-gray-300">Glow</summary>
                <div class="p-2 space-y-4">
                   <!-- Color -->
                  <div class="flex items-center justify-between">
                    <label for="glow-color" class="text-gray-400">Color</label>
                    <input id="glow-color" type="color" [ngModel]="glowConfig().color" (ngModelChange)="updateGlow('color', $event)" class="w-8 h-8 p-0 border-none rounded cursor-pointer bg-transparent">
                  </div>
                  <!-- Blur -->
                  <div class="space-y-1">
                    <label for="glow-blur" class="text-gray-400 flex justify-between"><span>Blur</span> <span>{{ glowConfig().blur }}px</span></label>
                    <input id="glow-blur" type="range" min="0" max="100" [ngModel]="glowConfig().blur" (ngModelChange)="updateGlow('blur', $event)" class="slider">
                  </div>
                  <!-- Intensity -->
                  <div class="space-y-1">
                    <label for="glow-intensity" class="text-gray-400 flex justify-between"><span>Intensity</span> <span>{{ (glowConfig().intensity * 100).toFixed(0) }}%</span></label>
                    <input id="glow-intensity" type="range" min="0" max="1" step="0.05" [ngModel]="glowConfig().intensity" (ngModelChange)="updateGlow('intensity', $event)" class="slider">
                  </div>
                  <button (click)="applyGlow()" class="w-full text-black font-semibold py-2 px-4 rounded-md transition-opacity hover:opacity-90" style="background: var(--gold-gradient)">Apply</button>
                </div>
              </details>
            </div>
          </div>
        }
      }

      <!-- AI Content Generation Panel -->
      <div class="bg-black/20 rounded-lg border border-[var(--border-color)] mt-auto">
        <header class="flex items-center justify-between p-3 border-b border-[var(--border-color)]">
          <h3 class="font-semibold">AI Content Generation</h3>
        </header>
        <div class="p-3 space-y-3">
          <textarea 
              [ngModel]="generativeFillPrompt()"
              (ngModelChange)="generativeFillPrompt.set($event)"
              rows="3"
              class="bg-black/20 border border-[var(--border-color)] rounded-md p-2 w-full text-sm placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-[var(--gold-text)]"
              placeholder="Describe what you want to generate..."
            ></textarea>
            <button 
              (click)="performGenerativeFill()"
              class="w-full text-black font-semibold py-2 px-4 rounded-md transition-opacity hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
              [style.background]="canGenerativeFill() && generativeFillPrompt().trim() ? 'var(--gold-gradient)' : '#4b5563'"
              [disabled]="!canGenerativeFill() || !generativeFillPrompt().trim()"
            >
              Generate
            </button>
        </div>
      </div>
      
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RightPanelComponent {
  editorState = inject(EditorStateService);
  
  generativeFillPrompt = signal('');
  imageGenPrompt = signal('');
  imageGenAspectRatio = signal<'1:1' | '16:9' | '9:16' | '4:3' | '3:4'>('1:1');

  readonly aspectRatios = [
    { label: '1:1', value: '1:1' as const },
    { label: '16:9', value: '16:9' as const },
    { label: '9:16', value: '9:16' as const },
    { label: '4:3', value: '4:3' as const },
    { label: '3:4', value: '3:4' as const },
  ];

  readonly activeTool = this.editorState.activeTool;
  readonly textConfig = this.editorState.textEditConfig;
  readonly layers = this.editorState.layers;
  readonly activeLayer = this.editorState.activeLayer;
  readonly canGenerativeFill = computed(() => !!this.editorState.selectionBounds() || !!this.editorState.subjectPolygon());

  readonly selectedRegion = computed(() => this.editorState.textEditConfig().selectedRegion);
  readonly canApply = computed(() => {
      const config = this.editorState.textEditConfig();
      return !!config.selectedRegion && !!config.newText.trim() && config.newText.trim() !== config.originalText;
  });

  // Effect states
  dropShadowConfig = signal<DropShadowEffect>({
    type: 'drop-shadow',
    color: '#000000',
    offsetX: 5,
    offsetY: 5,
    blur: 10
  });

  glowConfig = signal<GlowEffect>({
      type: 'glow',
      color: '#ffff00',
      blur: 20,
      intensity: 0.8
  });
  
  updateNewText(text: string) {
    this.editorState.setTextConfig({ newText: text });
  }

  applyChanges() {
    this.editorState.applyTextReplacement();
  }

  unselectRegion() {
    this.editorState.setTextConfig({ selectedRegion: null, newText: '', originalText: '' });
  }
  
  selectLayer(layerId: string) {
    this.editorState.setActiveLayerId(layerId);
  }

  updateDropShadow(prop: keyof DropShadowEffect, value: string | number) {
    this.dropShadowConfig.update(c => ({ ...c, [prop]: typeof value === 'string' && prop !== 'color' ? +value : value }));
  }

  applyDropShadow() {
    this.editorState.applyEffectToActiveLayer(this.dropShadowConfig());
  }

  updateGlow(prop: keyof GlowEffect, value: string | number) {
    this.glowConfig.update(c => ({ ...c, [prop]: typeof value === 'string' && prop !== 'color' ? +value : value }));
  }

  applyGlow() {
    this.editorState.applyEffectToActiveLayer(this.glowConfig());
  }

  generateImage() {
    const prompt = this.imageGenPrompt().trim();
    if (!prompt) {
      this.editorState.addNotification('warning', 'Please enter a prompt to generate an image.');
      return;
    }
    this.editorState.performImageGeneration(prompt, this.imageGenAspectRatio());
    this.imageGenPrompt.set('');
  }

  performGenerativeFill() {
    const prompt = this.generativeFillPrompt().trim();
    if (!prompt) {
      this.editorState.addNotification('warning', 'Please enter a prompt for generative fill.');
      return;
    }
    this.editorState.performGenerativeFill(prompt);
    this.generativeFillPrompt.set('');
  }
}