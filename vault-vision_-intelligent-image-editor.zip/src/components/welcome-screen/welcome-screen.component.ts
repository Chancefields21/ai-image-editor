import { Component, ChangeDetectionStrategy, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorStateService } from '../../services/editor-state.service';

@Component({
  selector: 'app-welcome-screen',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './welcome-screen.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WelcomeScreenComponent {
  imageUploaded = output<HTMLImageElement>();
  isDragging = signal(false);
  
  private editorState = inject(EditorStateService);

  onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const files = target.files;
    if (files && files[0]) {
      this.loadImage(files[0]);
    }
  }
  
  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragging.set(true);
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.isDragging.set(false);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragging.set(false);
    if (event.dataTransfer?.files && event.dataTransfer.files[0]) {
      this.loadImage(event.dataTransfer.files[0]);
    }
  }

  private loadImage(file: File): void {
    if (!file.type.startsWith('image/')) {
      this.editorState.addNotification('error', 'Please upload a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      const img = new Image();
      img.onload = () => {
        this.imageUploaded.emit(img);
      };
      img.onerror = () => {
          this.editorState.addNotification('error', 'Could not load the image file.');
      }
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }
}
