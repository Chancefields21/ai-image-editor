import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * This component is currently not used in the application.
 * The text editing functionality has been moved to the right-side panel.
 * This component has been stubbed out to resolve compilation errors.
 */
@Component({
  selector: 'app-text-editor-modal',
  standalone: true,
  imports: [CommonModule],
  template: ``,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TextEditorModalComponent {}
