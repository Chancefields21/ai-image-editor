
import { Component, ChangeDetectionStrategy, output, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuItem } from '../../types';
import { TopMenuDropdownComponent } from '../top-menu-dropdown/top-menu-dropdown.component';
import { EditorStateService } from '../../services/editor-state.service';

@Component({
  selector: 'app-top-menu',
  standalone: true,
  imports: [CommonModule, TopMenuDropdownComponent],
  template: `
    <header class="h-12 bg-[#1e1e1e] border-b border-[var(--border-color)] flex items-center px-4 shrink-0 z-20">
      <div class="flex items-center gap-2">
        <svg class="w-8 h-8 text-amber-400" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="M2.5,3 L12,15 L21.5,3 L17,3 L12,9 L7,3 Z"></path>
            <path d="M7,11 L12,17 L17,11 L14.5,11 L12,14 L9.5,11 Z"></path>
        </svg>
        <h1 class="font-semibold text-lg text-gray-100">Vision Vault Studio</h1>
      </div>
      
      <div class="flex items-center gap-1 text-sm ml-6">
        <app-top-menu-dropdown label="File" [items]="fileMenuItems" />
        <app-top-menu-dropdown label="Edit" [items]="editMenuItems()" />
        <button class="px-3 py-1.5 rounded-md hover:bg-white/10 transition-colors">Layer</button>
      </div>
      
      <div class="flex-grow"></div>

      <div class="flex items-center gap-4 text-gray-400">
        <button class="hover:text-white" title="Cloud Sync">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15a4.5 4.5 0 0 0 4.5 4.5H18a3.75 3.75 0 0 0 1.332-7.257 3 3 0 0 0-5.43-2.035A4.5 4.5 0 0 0 6.75 10.5H5.25a2.25 2.25 0 0 0-2.25 2.25Z" /></svg>
        </button>
        <button class="hover:text-white" title="Profile">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
        </button>
        <button class="hover:text-white" title="Settings">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-1.007 1.11-1.226.55-.22 1.156-.22 1.706 0 .55.219 1.02.684 1.11 1.226l.082.499a1.875 1.875 0 0 0 2.323.815l.445-.222a1.875 1.875 0 0 1 2.164 1.055l.255.51a1.875 1.875 0 0 1-1.055 2.164l-.222.445a1.875 1.875 0 0 0 .815 2.323l.499.082c.542.09.997.56 1.226 1.11.22.55.22 1.156 0 1.706-.219.55-.684 1.02-1.226 1.11l-.499.082a1.875 1.875 0 0 0-.815 2.323l.222.445a1.875 1.875 0 0 1-1.055 2.164l-.51.255a1.875 1.875 0 0 1-2.164-1.055l-.445-.222a1.875 1.875 0 0 0-2.323.815l-.082.499c-.09.542-.56 1.007-1.11 1.226-.55.22-1.156-.22-1.706 0-.55-.219-1.02-.684-1.11-1.226l-.082-.499a1.875 1.875 0 0 0-2.323-.815l-.445.222a1.875 1.875 0 0 1-2.164-1.055l-.255-.51a1.875 1.875 0 0 1 1.055-2.164l.222-.445a1.875 1.875 0 0 0-.815-2.323l-.499-.082c-.542-.09-.997-.56-1.226-1.11-.22-.55-.22-1.156 0-1.706.219.55.684-1.02 1.226-1.11l.499-.082a1.875 1.875 0 0 0 .815-2.323l-.222-.445a1.875 1.875 0 0 1 1.055-2.164l.51-.255a1.875 1.875 0 0 1 2.164 1.055l.445.222a1.875 1.875 0 0 0 2.323-.815l.082-.499Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" /></svg>
        </button>
      </div>
    </header>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopMenuComponent {
  openFile = output<void>();
  closeFile = output<void>();
  private editorState = inject(EditorStateService);

  readonly editMenuItems = computed<MenuItem[]>(() => [
    { label: 'Undo', shortcut: 'Ctrl+Z', action: () => this.editorState.undo(), disabled: !this.editorState.canUndo() },
    { label: 'Redo', shortcut: 'Ctrl+Y', action: () => this.editorState.redo(), disabled: !this.editorState.canRedo() },
  ]);

  readonly fileMenuItems: MenuItem[] = [
    { label: 'New Project', shortcut: 'Ctrl+N', disabled: true },
    { label: 'Open Image...', shortcut: 'Ctrl+O', action: () => this.openFile.emit() },
    { label: 'Open Recent', items: [{label: 'No recent files', disabled: true}] },
    { label: 'Import from URL...', shortcut: 'Ctrl+Shift+O', disabled: true },
    { label: 'separator-1', separator: true },
    { label: 'Save', shortcut: 'Ctrl+S', disabled: true },
    { label: 'Save As...', shortcut: 'Ctrl+Shift+S', disabled: true },
    { 
      label: 'Export As', 
      items: [
        { label: 'PNG', disabled: true },
        { label: 'JPEG', disabled: true },
        { label: 'WebP', disabled: true },
        { label: 'SVG (if vectorized)', disabled: true },
        { label: 'PDF', disabled: true },
      ]
    },
    { label: 'Export for Web...', shortcut: 'Ctrl+Alt+Shift+S', disabled: true },
    { label: 'separator-2', separator: true },
    { label: 'Auto-Save Settings...', disabled: true },
    { label: 'Project Settings...', disabled: true },
    { label: 'separator-3', separator: true },
    { label: 'Close', shortcut: 'Ctrl+W', action: () => this.closeFile.emit() },
    { label: 'Exit', shortcut: 'Ctrl+Q', disabled: true },
  ];
}
