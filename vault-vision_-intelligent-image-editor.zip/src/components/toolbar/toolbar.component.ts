

import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorStateService } from '../../services/editor-state.service';
import { ToolType } from '../../types';

interface Tool {
  id: ToolType;
  name: string;
  icon: string;
}

interface ToolSection {
  name: string;
  tools: Tool[];
}

@Component({
  selector: 'app-toolbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toolbar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ToolbarComponent {
  editorState = inject(EditorStateService);
  activeTool = this.editorState.activeTool;
  
  // History state
  history = this.editorState.history;
  currentIndex = this.editorState.currentIndex;

  toolSections: ToolSection[] = [
    {
      name: 'File',
      tools: [
        { id: 'crop', name: 'Crop', icon: 'M3.105 2.105a.75.75 0 0 1 .89.252L4.25 3h15.5a.75.75 0 0 1 0 1.5H4.25l-.255.255A.75.75 0 0 1 3.105 4.395V2.105Zm17.79 17.79a.75.75 0 0 1-.89-.252L19.75 21H4.25a.75.75 0 0 1 0-1.5h15.5l.255-.255a.75.75 0 0 1 .89.605v2.295Z' },
      ]
    },
    {
      name: 'Selection',
      tools: [
        { id: 'selection', name: 'Selection', icon: 'M9 4.5v15m6-15v15m-10.875 0h15.75c.621 0 1.125-.504 1.125-1.125V5.625c0-.621-.504-1.125-1.125-1.125H4.125A1.125 1.125 0 0 0 3 5.625v12.75c0 .621.504 1.125 1.125 1.125Z' },
        { id: 'crop', name: 'Crop', icon: 'M3.105 2.105a.75.75 0 0 1 .89.252L4.25 3h15.5a.75.75 0 0 1 0 1.5H4.25l-.255.255A.75.75 0 0 1 3.105 4.395V2.105Zm17.79 17.79a.75.75 0 0 1-.89-.252L19.75 21H4.25a.75.75 0 0 1 0-1.5h15.5l.255-.255a.75.75 0 0 1 .89.605v2.295Z' },
        { id: 'brush', name: 'Brush', icon: 'M9.53 16.122a3 3 0 0 0-2.06-2.06L2.645 12l4.825-1.928a3 3 0 0 0 2.06-2.06L12 2.645l1.928 4.825a3 3 0 0 0 2.06 2.06L21.355 12l-4.825 1.928a3 3 0 0 0-2.06 2.06L12 21.355l-1.928-4.825a3 3 0 0 0-2.06-2.06L2.645 12l4.825 1.928a3 3 0 0 0 2.06 2.06L12 21.355l-1.928-4.825Z' },
        { id: 'text', name: 'Text', icon: 'M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125' },
      ]
    },
    {
      name: 'AI Tools',
      tools: [
        { id: 'object-removal', name: 'AI Object Removal/Heal', icon: 'M15.362 5.214A8.252 8.252 0 0 1 12 21 8.25 8.25 0 0 1 6.038 7.048l-2.048-2.048a.75.75 0 0 1 1.06-1.06l2.048 2.048A8.207 8.207 0 0 1 12 3c1.802 0 3.473.613 4.82 1.638l-1.458 1.458ZM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z' },
        { id: 'image-generation', name: 'AI Image Generation', icon: 'M2.25 15.75l5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z' },
        { id: 'upscale', name: 'AI Upscale', icon: 'M3 8.25V18a2.25 2.25 0 0 0 2.25 2.25h13.5A2.25 2.25 0 0 0 21 18V8.25M15 12 12 9l-3 3m12-3-3-3-3 3' },
        { id: 'content-to-path', name: 'AI Content-to-Path', icon: 'M11.47 1.72a.75.75 0 0 1 1.06 0l3 3a.75.75 0 0 1-1.06 1.06l-1.72-1.72V7.5h-1.5V4.06L9.53 5.78a.75.75 0 0 1-1.06-1.06l3-3ZM11.25 7.5V15a.75.75 0 0 0 .75.75h3.75a.75.75 0 0 0 0-1.5H12.75V7.5h-1.5Z' },
      ]
    }
  ];

  selectTool(toolId: ToolType): void {
    this.editorState.setActiveTool(toolId);
    if (toolId === 'text') {
        if (!this.editorState.textEditConfig().detectedRegions?.length) {
            this.editorState.detectAndAnalyzeText();
        }
    } else if (toolId === 'content-to-path') {
        this.editorState.selectSubject();
    }
  }

  revertToState(index: number) {
    this.editorState.revertToHistoryState(index);
  }
}