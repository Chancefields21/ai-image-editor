import { Component, ChangeDetectionStrategy, inject, viewChild, ElementRef, effect, computed, HostListener, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorStateService } from '../../services/editor-state.service';
import { EnhancedTextRegion, TextStyle } from '../../types';
import { renderEnhancedText } from '../../utils/canvas-text';

@Component({
  selector: 'app-canvas-workspace',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './canvas-workspace.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CanvasWorkspaceComponent {
  editorState = inject(EditorStateService);
  canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>('canvas');
  overlayRef = viewChild.required<ElementRef<HTMLCanvasElement>>('overlay');
  workspaceContainer = viewChild.required<ElementRef<HTMLDivElement>>('workspaceContainer');
  
  private ctx: CanvasRenderingContext2D | null = null;
  
  // State from service
  private readonly layers = this.editorState.layers;
  private readonly activeTool = this.editorState.activeTool;
  private readonly textConfig = this.editorState.textEditConfig;
  private readonly selection = this.editorState.selection;
  private readonly selectionBounds = this.editorState.selectionBounds;
  private readonly zoom = this.editorState.zoom;
  private readonly panOffset = this.editorState.panOffset;
  private readonly subjectPolygon = this.editorState.subjectPolygon;
  
  // Local component state for interactions
  private isPanMode = signal(false);
  private isPanning = signal(false);
  private lastPanPoint = signal({ x: 0, y: 0 });
  private hoverRegionId = signal<string | null>(null);
  private dashOffset = signal(0);

  // Computed properties
  canvasTransform = computed(() => {
    const pan = this.panOffset();
    const z = this.zoom();
    return `translate(${pan.x}px, ${pan.y}px) scale(${z})`;
  });

  constructor() {
    effect(() => {
      this.drawCanvas();
    });

    effect(() => {
      this.layers();
      this.activeTool();
      this.textConfig();
      this.selection();
      this.selectionBounds();
      this.zoom();
      this.hoverRegionId();
      this.subjectPolygon();
      this.dashOffset(); // Add dependency for animation
      this.drawOverlay();
    });

    effect(() => {
      const layers = this.layers();
      if (layers.length > 0) {
        this.centerAndFitImage();
      }
    }, { allowSignalWrites: true });

    // Effect for marching ants animation
    effect((onCleanup) => {
      let frameId: number;
      const animate = () => {
        this.dashOffset.update(d => (d + 0.5) % 16);
        frameId = requestAnimationFrame(animate);
      };
      
      if (this.subjectPolygon() || this.selectionBounds()) {
         frameId = requestAnimationFrame(animate);
      }
      
      onCleanup(() => {
        if (frameId) {
          cancelAnimationFrame(frameId);
        }
      });
    }, { allowSignalWrites: true });
  }

  private centerAndFitImage() {
    const layers = this.layers();
    if (layers.length === 0) return;

    const container = this.workspaceContainer()?.nativeElement;
    if (!container) return;
    
    requestAnimationFrame(() => {
      const imgW = layers[0].image.naturalWidth;
      const imgH = layers[0].image.naturalHeight;
      const containerW = container.clientWidth;
      const containerH = container.clientHeight;

      const scaleX = containerW / imgW;
      const scaleY = containerH / imgH;
      const zoom = Math.min(scaleX, scaleY, 1) * 0.9;

      const newW = imgW * zoom;
      const newH = imgH * zoom;

      const panX = (containerW - newW) / 2;
      const panY = (containerH - newH) / 2;

      this.editorState.setZoom(zoom);
      this.editorState.setPanOffset({ x: panX, y: panY });
    });
  }

  private getImageCoords(event: MouseEvent): { x: number; y: number } {
    const container = this.workspaceContainer().nativeElement;
    const rect = container.getBoundingClientRect();
    const viewX = event.clientX - rect.left;
    const viewY = event.clientY - rect.top;

    const pan = this.panOffset();
    const zoom = this.zoom();

    const imageX = (viewX - pan.x) / zoom;
    const imageY = (viewY - pan.y) / zoom;
    
    return { x: imageX, y: imageY };
  }

  private drawCanvas() {
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    
    const layers = this.layers();
    if (layers.length === 0) {
      canvas.width = 0; canvas.height = 0;
      return;
    };
    
    const baseLayer = layers[0];
    if (canvas.width !== baseLayer.image.naturalWidth || canvas.height !== baseLayer.image.naturalHeight) {
      canvas.width = baseLayer.image.naturalWidth;
      canvas.height = baseLayer.image.naturalHeight;

      const overlay = this.overlayRef().nativeElement;
      overlay.width = canvas.width;
      overlay.height = canvas.height;
    }

    this.ctx = canvas.getContext('2d');
    if (!this.ctx) return;
    this.ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (const layer of layers) {
      if (layer.isVisible && this.ctx) {
        this.ctx.globalAlpha = layer.opacity;
        this.ctx.globalCompositeOperation = layer.blendMode;
        this.ctx.drawImage(layer.image, 0, 0);
      }
    }
    
    this.ctx.globalAlpha = 1;
    this.ctx.globalCompositeOperation = 'source-over';
  }

  private drawOverlay() {
    const overlay = this.overlayRef()?.nativeElement;
    if (!overlay || this.layers().length === 0) return;
    
    const ctx = overlay.getContext('2d')!;
    ctx.clearRect(0, 0, overlay.width, overlay.height);
    
    const zoom = this.zoom();
    const tool = this.activeTool();

    if (tool === 'text') {
      const regions = this.textConfig().detectedRegions || [];
      const selected = this.textConfig().selectedRegion;
      const hoverId = this.hoverRegionId();
      
      for (const region of regions) {
        if (region.quad.length < 4) continue;
        const isHover = hoverId === region.id;
        const isSelected = selected?.id === region.id;

        if (!isSelected) {
          ctx.beginPath();
          ctx.moveTo(region.quad[0].x, region.quad[0].y);
          for(let i=1; i < region.quad.length; i++) {
            ctx.lineTo(region.quad[i].x, region.quad[i].y);
          }
          ctx.closePath();
          
          ctx.lineWidth = 1.5 / zoom;
          ctx.strokeStyle = isHover ? '#a78bfa' : '#6366f1';
          ctx.fillStyle = isHover ? 'rgba(167,139,250,0.15)' : 'rgba(99,102,241,0.1)';
          ctx.fill();
          ctx.stroke();
        }
      }
      this.drawLiveTextPreview(ctx);
    }
    
    const subjectPolygon = this.subjectPolygon();
    if (subjectPolygon && subjectPolygon.length > 2) {
      this.drawMarchingAnts(ctx, subjectPolygon.map(p => [p.x, p.y]));
    }

    const bounds = this.selectionBounds();
    if (bounds && (tool === 'object-removal' || tool === 'selection')) {
        const polygon = [
            [bounds.x, bounds.y],
            [bounds.x + bounds.width, bounds.y],
            [bounds.x + bounds.width, bounds.y + bounds.height],
            [bounds.x, bounds.y + bounds.height]
        ];
        this.drawMarchingAnts(ctx, polygon);
    }

    const selection = this.selection();
    if (selection.isSelecting && selection.startPoint && selection.endPoint && (tool === 'selection' || tool === 'object-removal')) {
      ctx.strokeStyle = '#38bdf8';
      ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
      ctx.lineWidth = 1.5 / zoom;
      ctx.strokeRect(selection.startPoint.x, selection.startPoint.y, selection.endPoint.x - selection.startPoint.x, selection.endPoint.y - selection.startPoint.y);
      ctx.fillRect(selection.startPoint.x, selection.startPoint.y, selection.endPoint.x - selection.startPoint.x, selection.endPoint.y - selection.startPoint.y);
    }
  }

  private drawMarchingAnts(ctx: CanvasRenderingContext2D, points: number[][]) {
    const zoom = this.zoom();
    ctx.save();
    ctx.lineWidth = 1 / zoom;
    
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i][0], points[i][1]);
    }
    ctx.closePath();

    // Black dashes
    ctx.strokeStyle = '#000000';
    ctx.setLineDash([4 / zoom, 4 / zoom]);
    ctx.lineDashOffset = this.dashOffset() / zoom;
    ctx.stroke();

    // White dashes
    ctx.strokeStyle = '#ffffff';
    ctx.lineDashOffset = (this.dashOffset() + 4) / zoom;
    ctx.stroke();

    ctx.restore();
  }

  private drawLiveTextPreview(ctx: CanvasRenderingContext2D) {
    const config = this.textConfig();
    const selectedRegion = config.selectedRegion;
    const newText = config.newText;

    if (!selectedRegion) return;
    
    const zoom = this.zoom();
    
    // Draw the main selection quad
    ctx.beginPath();
    ctx.moveTo(selectedRegion.quad[0].x, selectedRegion.quad[0].y);
    for(let i=1; i < selectedRegion.quad.length; i++) {
      ctx.lineTo(selectedRegion.quad[i].x, selectedRegion.quad[i].y);
    }
    ctx.closePath();
    ctx.lineWidth = 2.5 / zoom;
    ctx.strokeStyle = '#22d3ee';
    ctx.fillStyle = 'rgba(34,211,238,0.2)';
    ctx.fill();
    ctx.stroke();

    if (!newText) return;

    // Use the new rendering utility for an accurate preview
    const styleOverride = config.preserveStyle ? undefined : config.customStyle;
    renderEnhancedText(ctx, newText, selectedRegion, styleOverride);
  }

  onWheel(event: WheelEvent) {
    event.preventDefault();

    const zoomFactor = 1.1;
    const oldZoom = this.zoom();
    const newZoom = event.deltaY < 0 ? oldZoom * zoomFactor : oldZoom / zoomFactor;
    const clampedZoom = Math.max(0.1, Math.min(newZoom, 10));

    const container = this.workspaceContainer().nativeElement;
    const rect = container.getBoundingClientRect();
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;

    const oldPan = this.panOffset();
    const imageX = (mouseX - oldPan.x) / oldZoom;
    const imageY = (mouseY - oldPan.y) / oldZoom;
    const newPanX = mouseX - imageX * clampedZoom;
    const newPanY = mouseY - imageY * clampedZoom;

    this.editorState.setZoom(clampedZoom);
    this.editorState.setPanOffset({ x: newPanX, y: newPanY });
  }

  onMouseDown(event: MouseEvent) {
    if (this.isPanMode()) {
      this.isPanning.set(true);
      this.lastPanPoint.set({ x: event.clientX, y: event.clientY });
      return;
    }
    
    const tool = this.activeTool();
    if (tool !== 'selection' && tool !== 'object-removal') return;
    
    const { x: imgX, y: imgY } = this.getImageCoords(event);
    if (tool === 'object-removal' || tool === 'selection') this.editorState.setSelectionBounds(null);
    this.editorState.setSelectionState(() => ({
      isSelecting: true,
      startPoint: { x: imgX, y: imgY },
      endPoint: { x: imgX, y: imgY },
    }));
  }

  onMouseMove(event: MouseEvent) {
    if (this.isPanning()) {
      const currentPan = this.panOffset();
      const lastPoint = this.lastPanPoint();
      const dx = event.clientX - lastPoint.x;
      const dy = event.clientY - lastPoint.y;
      this.editorState.setPanOffset({ x: currentPan.x + dx, y: currentPan.y + dy });
      this.lastPanPoint.set({ x: event.clientX, y: event.clientY });
      return;
    }
    
    const { x: imgX, y: imgY } = this.getImageCoords(event);
    const tool = this.activeTool();

    if ((tool === 'selection' || tool === 'object-removal') && this.selection().isSelecting) {
      this.editorState.setSelectionState(() => ({ endPoint: { x: imgX, y: imgY } }));
    } else if (tool === 'text') {
      const regions = this.textConfig().detectedRegions || [];
      const hit = regions.find(r =>
        imgX >= r.bounds.x && imgX <= r.bounds.x + r.bounds.width &&
        imgY >= r.bounds.y && imgY <= r.bounds.y + r.bounds.height
      );
      this.hoverRegionId.set(hit?.id || null);
    }
  }

  onMouseUp() {
    if (this.isPanning()) {
      this.isPanning.set(false);
      return;
    }
    
    const tool = this.activeTool();
    if ((tool === 'selection' || tool === 'object-removal') && this.selection().isSelecting) {
      const selection = this.selection();
      if (selection.startPoint && selection.endPoint) {
        const x = Math.min(selection.startPoint.x, selection.endPoint.x);
        const y = Math.min(selection.startPoint.y, selection.endPoint.y);
        const width = Math.abs(selection.endPoint.x - selection.startPoint.x);
        const height = Math.abs(selection.endPoint.y - selection.startPoint.y);

        if (width > 5 && height > 5) {
          this.editorState.setSelectionBounds({ x, y, width, height });
          if(tool === 'selection') {
              this.editorState.addNotification('info', 'Rectangular selection created.');
          }
        }
      }
      this.editorState.setSelectionState(() => ({ isSelecting: false, startPoint: undefined, endPoint: undefined }));
    }
  }

  onMouseLeave() {
    this.hoverRegionId.set(null);
    if (this.selection().isSelecting) this.onMouseUp();
    if (this.isPanning()) this.isPanning.set(false);
  }

  onClick(event: MouseEvent) {
    if (this.isPanMode() || this.isPanning()) return;

    if (this.activeTool() === 'text') {
      const { x: imgX, y: imgY } = this.getImageCoords(event);
      const regions = this.textConfig().detectedRegions || [];
      const hit = regions.find(r =>
        imgX >= r.bounds.x && imgX <= r.bounds.x + r.bounds.width &&
        imgY >= r.bounds.y && imgY <= r.bounds.y + r.bounds.height
      );
      if (hit) {
        this.editorState.setTextConfig({ selectedRegion: hit, originalText: hit.text, newText: hit.text });
        this.editorState.addNotification('info', `Selected region: "${hit.text}"`);
      }
    }
  }

  onDblClick(event: MouseEvent) { }

  @HostListener('window:keydown.space', ['$event'])
  onSpaceDown(event: KeyboardEvent) {
    if ((event.target as HTMLElement).nodeName !== 'BODY') return;
    event.preventDefault();
    this.isPanMode.set(true);
  }

  @HostListener('window:keyup.space')
  onSpaceUp() {
    this.isPanMode.set(false);
    if (this.isPanning()) this.isPanning.set(false);
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      if (this.selection().isSelecting) {
        this.editorState.setSelectionState(() => ({ isSelecting: false, startPoint: undefined, endPoint: undefined }));
      }
      if (this.selectionBounds()) {
        this.editorState.setSelectionBounds(null);
      }
    } else if (event.key === '+' || event.key === '=') {
      event.preventDefault();
      this.zoomAtCenter(1.2);
    } else if (event.key === '-' || event.key === '_') {
      event.preventDefault();
      this.zoomAtCenter(1 / 1.2);
    }
  }

  private zoomAtCenter(zoomFactor: number) {
    const oldZoom = this.zoom();
    const newZoom = oldZoom * zoomFactor;
    const clampedZoom = Math.max(0.1, Math.min(newZoom, 10));

    const container = this.workspaceContainer().nativeElement;
    const centerX = container.clientWidth / 2;
    const centerY = container.clientHeight / 2;
    
    const oldPan = this.panOffset();
    const imageX = (centerX - oldPan.x) / oldZoom;
    const imageY = (centerY - oldPan.y) / oldZoom;

    const newPanX = centerX - imageX * clampedZoom;
    const newPanY = centerY - imageY * clampedZoom;

    this.editorState.setZoom(clampedZoom);
    this.editorState.setPanOffset({ x: newPanX, y: newPanY });
  }
}
