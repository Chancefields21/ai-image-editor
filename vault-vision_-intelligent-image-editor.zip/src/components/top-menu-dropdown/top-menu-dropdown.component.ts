import { Component, ChangeDetectionStrategy, input, signal, HostListener, ElementRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuItem } from '../../types';

@Component({
  selector: 'app-top-menu-dropdown',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative">
      <button 
        (click)="toggleDropdown()" 
        class="px-3 py-1.5 rounded-md transition-colors text-sm"
        [class]="isOpen() ? 'bg-white/10' : 'hover:bg-white/10'">
        {{ label() }}
      </button>

      @if (isOpen()) {
        <div 
          class="absolute left-0 mt-2 w-72 bg-[#2a2a2a] border border-[var(--border-color)] rounded-md shadow-2xl py-1 z-30"
          (click)="$event.stopPropagation()">
          @for (item of items(); track item.label) {
            @if (item.separator) {
              <hr class="my-1 border-white/10">
            } @else {
              <div class="relative group">
                <button 
                  (click)="onItemClick(item)"
                  [disabled]="item.disabled"
                  class="w-full text-left px-3 py-1.5 text-sm flex items-center justify-between transition-colors rounded-md mx-1"
                  [class]="item.disabled ? 'text-gray-500 cursor-not-allowed' : 'text-gray-200 hover:bg-white/5'">
                  <span class="flex-grow">{{ item.label }}</span>
                  <span class="text-gray-400 text-xs ml-4">{{ item.shortcut }}</span>
                  @if (item.items) {
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4 ml-2">
                      <path fill-rule="evenodd" d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd" />
                    </svg>
                  }
                </button>
                <!-- Submenu -->
                @if (item.items) {
                  <div class="absolute left-full -top-1 w-48 bg-[#2a2a2a] border border-[var(--border-color)] rounded-md shadow-2xl py-1 z-30 hidden group-hover:block">
                    @for(subItem of item.items; track subItem.label) {
                       <button 
                          (click)="onItemClick(subItem)"
                          [disabled]="subItem.disabled"
                          class="w-full text-left px-3 py-1.5 text-sm flex items-center justify-between transition-colors rounded-md mx-1"
                          [class]="subItem.disabled ? 'text-gray-500 cursor-not-allowed' : 'text-gray-200 hover:bg-white/5'">
                          <span>{{ subItem.label }}</span>
                        </button>
                    }
                  </div>
                }
              </div>
            }
          }
        </div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TopMenuDropdownComponent {
  label = input.required<string>();
  items = input.required<MenuItem[]>();

  isOpen = signal(false);
  private elementRef = inject(ElementRef);

  toggleDropdown(): void {
    this.isOpen.update(open => !open);
  }

  closeDropdown(): void {
    this.isOpen.set(false);
  }

  onItemClick(item: MenuItem): void {
    if (item.disabled || item.items?.length) {
      return;
    }
    item.action?.();
    this.closeDropdown();
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.closeDropdown();
    }
  }
}
