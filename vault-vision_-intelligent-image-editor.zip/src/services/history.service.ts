
import { Injectable, signal, computed } from '@angular/core';
import { Layer } from '../types';

export interface HistoryState {
  layers: Layer[];
  actionName: string;
  timestamp: number;
}

const MAX_HISTORY_STATES = 50;

@Injectable({
  providedIn: 'root',
})
export class HistoryService {
  private readonly _history = signal<HistoryState[]>([]);
  private readonly _currentIndex = signal<number>(-1);

  readonly history = this._history.asReadonly();
  readonly currentIndex = this._currentIndex.asReadonly();

  readonly canUndo = computed(() => this._currentIndex() > 0);
  readonly canRedo = computed(() => this._currentIndex() < this._history().length - 1);

  pushState(layers: Layer[], actionName: string): void {
    const currentStateIndex = this._currentIndex();
    const history = this._history();
    
    // If we are not at the end of the history, truncate it
    const newHistory = history.slice(0, currentStateIndex + 1);

    // Create a deep enough clone of layers to prevent mutation issues.
    // Images are reference-based, which is fine, we just need a new array of layer objects.
    const clonedLayers = layers.map(layer => ({ ...layer }));

    const newState: HistoryState = {
      layers: clonedLayers,
      actionName,
      timestamp: Date.now(),
    };
    
    newHistory.push(newState);

    // Limit the number of history states
    if (newHistory.length > MAX_HISTORY_STATES) {
        newHistory.shift(); // Remove the oldest state
    }
    
    this._history.set(newHistory);
    this._currentIndex.set(newHistory.length - 1);
  }

  undo(): HistoryState | null {
    if (!this.canUndo()) return null;
    this._currentIndex.update(i => i - 1);
    return this._history()[this._currentIndex()];
  }

  redo(): HistoryState | null {
    if (!this.canRedo()) return null;
    this._currentIndex.update(i => i + 1);
    return this._history()[this._currentIndex()];
  }

  revertToState(index: number): HistoryState | null {
    if (index < 0 || index >= this._history().length) return null;
    this._currentIndex.set(index);
    return this._history()[index];
  }

  clearHistory(): void {
    this._history.set([]);
    this._currentIndex.set(-1);
  }
}
