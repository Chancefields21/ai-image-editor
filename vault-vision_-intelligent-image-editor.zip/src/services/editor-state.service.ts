import { Injectable, signal, inject, computed } from '@angular/core';
import {
  Layer,
  ToolType,
  TextEditConfig,
  TextStyle,
  SelectionState,
  Bounds,
  Point,
  Notification,
  EnhancedTextRegion,
  Effect,
} from '../types';
import { GeminiService } from './gemini.service';
import { LoadingStateService } from './loading-state.service';
import { HistoryService } from './history.service';
import { EffectsService } from './effects.service';
import { getBase64FromImage, createMaskFromPolygon, imageFromBase64 } from '../utils/image-edit';
import { finalize, forkJoin } from 'rxjs';
import { renderEnhancedText } from '../utils/canvas-text';

const DEFAULT_TEXT_STYLE: TextStyle = {
  color: '#000000',
  fontSize: 24,
  fontFamily: 'sans-serif',
  fontWeight: 'normal',
  fontStyle: 'normal',
  rotation: 0,
};

@Injectable({
  providedIn: 'root',
})
export class EditorStateService {
  private readonly geminiService = inject(GeminiService);
  private readonly loadingState = inject(LoadingStateService);
  private readonly historyService = inject(HistoryService);
  private readonly effectsService = inject(EffectsService);

  // State Signals
  private readonly _layers = signal<Layer[]>([]);
  private readonly _activeLayerId = signal<string | null>(null);
  private readonly _activeTool = signal<ToolType>('selection');
  private readonly _zoom = signal(1);
  private readonly _panOffset = signal({ x: 0, y: 0 });
  private readonly _textEditConfig = signal<TextEditConfig>({
    detectedRegions: [],
    selectedRegion: null,
    originalText: '',
    newText: '',
    preserveStyle: true,
    customStyle: DEFAULT_TEXT_STYLE,
  });
  private readonly _selection = signal<SelectionState>({ isSelecting: false });
  private readonly _selectionBounds = signal<Bounds | null>(null);
  private readonly _subjectPolygon = signal<Point[] | null>(null);
  private readonly _notifications = signal<Notification[]>([]);

  // Readonly Signals (Public API)
  readonly layers = this._layers.asReadonly();
  readonly activeLayerId = this._activeLayerId.asReadonly();
  readonly activeLayer = computed(() => {
    const layers = this._layers();
    const activeId = this._activeLayerId();
    if (!activeId && layers.length > 0) {
      return layers[layers.length - 1]; // Default to top layer
    }
    return layers.find(l => l.id === activeId) || null;
  });
  readonly activeTool = this._activeTool.asReadonly();
  readonly zoom = this._zoom.asReadonly();
  readonly panOffset = this._panOffset.asReadonly();
  readonly textEditConfig = this._textEditConfig.asReadonly();
  readonly selection = this._selection.asReadonly();
  readonly selectionBounds = this._selectionBounds.asReadonly();
  readonly subjectPolygon = this._subjectPolygon.asReadonly();
  readonly notifications = this._notifications.asReadonly();

  // History Signals delegated from HistoryService
  readonly history = this.historyService.history;
  readonly currentIndex = this.historyService.currentIndex;
  readonly canUndo = this.historyService.canUndo;
  readonly canRedo = this.historyService.canRedo;

  // Methods to update state
  setInitialImage(image: HTMLImageElement): void {
      const baseLayer: Layer = {
          id: `layer-${Date.now()}`,
          name: 'Background',
          image,
          thumbnail: this.createThumbnail(image),
          isVisible: true,
          opacity: 1,
          blendMode: 'source-over',
      };
      this._layers.set([baseLayer]);
      this.setActiveLayerId(baseLayer.id);
      this.historyService.clearHistory();
      this.historyService.pushState([baseLayer], 'Initial Image');
  }

  closeImage(): void {
    this._layers.set([]);
    this._activeLayerId.set(null);
    this._textEditConfig.set({
      detectedRegions: [],
      selectedRegion: null,
      originalText: '',
      newText: '',
      preserveStyle: true,
      customStyle: DEFAULT_TEXT_STYLE,
    });
    this._selection.set({ isSelecting: false });
    this._selectionBounds.set(null);
    this._subjectPolygon.set(null);
    this._zoom.set(1);
    this._panOffset.set({ x: 0, y: 0 });
    this.setActiveTool('selection');
    this.historyService.clearHistory();
  }
  
  addLayer(image: HTMLImageElement, name: string): void {
    const newLayer: Layer = {
      id: `layer-${Date.now()}`,
      name,
      image,
      thumbnail: this.createThumbnail(image),
      isVisible: true,
      opacity: 1,
      blendMode: 'source-over',
    };
    const currentLayers = this._layers();
    const newLayers = [...currentLayers, newLayer];
    this._layers.set(newLayers);
    this.setActiveLayerId(newLayer.id);
    this.historyService.pushState(newLayers, name);
  }

  setActiveLayerId(id: string | null): void {
    this._activeLayerId.set(id);
  }

  setActiveTool(tool: ToolType): void {
    this._activeTool.set(tool);
    // Reset selections when changing tools
    this._selectionBounds.set(null);
    this.setSelectionState(() => ({ isSelecting: false }));
    if (tool !== 'text') {
        this.setTextConfig({ selectedRegion: null });
    }
  }

  setZoom(zoom: number): void {
    this._zoom.set(zoom);
  }

  setPanOffset(offset: Point): void {
    this._panOffset.set(offset);
  }

  setTextConfig(config: Partial<TextEditConfig>): void {
    this._textEditConfig.update(current => ({ ...current, ...config }));
  }

  setSelectionState(updater: (state: SelectionState) => Partial<SelectionState>): void {
      this._selection.update(current => ({ ...current, ...updater(current) }));
  }

  setSelectionBounds(bounds: Bounds | null): void {
    this._selectionBounds.set(bounds);
    if(bounds) {
        this._subjectPolygon.set(null); // Clear polygon if bounds are set
    }
  }

  addNotification(type: Notification['type'], message: string): void {
    const newNotification: Notification = {
      id: Date.now(),
      type,
      message,
    };
    this._notifications.update(notifications => [...notifications, newNotification]);
    setTimeout(() => {
      this._notifications.update(notifications => notifications.filter(n => n.id !== newNotification.id));
    }, 5000);
  }

  // Gemini-related actions
  detectAndAnalyzeText(): void {
    const baseLayer = this.layers()[0];
    if (!baseLayer) return;

    this.loadingState.startLoading('Analyzing text...');
    const imageDataUrl = getBase64FromImage(baseLayer.image);

    this.geminiService.detectAndAnalyzeText(imageDataUrl).pipe(
      finalize(() => this.loadingState.stopLoading())
    ).subscribe({
      next: (regions) => {
        this.setTextConfig({ detectedRegions: regions });
        this.addNotification('success', `Found ${regions.length} text regions.`);
      },
      error: (err) => {
        console.error('Text analysis failed', err);
        this.addNotification('error', 'Failed to detect text regions.');
      }
    });
  }

  applyTextReplacement(): void {
    const config = this.textEditConfig();
    const region = config.selectedRegion;
    const newText = config.newText;
    const baseLayer = this.layers()[0];

    if (!region || !newText || !baseLayer) {
        this.addNotification('error', 'Missing data for text replacement.');
        return;
    }
    
    this.loadingState.startLoading('Replacing text with AI optimization...');
    
    const { naturalWidth, naturalHeight } = baseLayer.image;
    const imageDataUrl = getBase64FromImage(baseLayer.image);
    const maskDataUrl = createMaskFromPolygon(naturalWidth, naturalHeight, region.quad);
    const inpaintPrompt = "Analyze the image and the mask. The mask is white where the content should be replaced. Inpaint the white area to seamlessly remove the text and restore the original background texture and lighting."

    const inpaint$ = this.geminiService.generativeFill(imageDataUrl, maskDataUrl, inpaintPrompt);
    const textOptimization$ = this.geminiService.getOptimalTextVariation(region, newText);

    forkJoin({ patchBase64: inpaint$, optimalParams: textOptimization$ }).pipe(
        finalize(() => this.loadingState.stopLoading())
    ).subscribe({
        next: async ({ patchBase64, optimalParams }) => {
            try {
                const inpaintedPatch = await imageFromBase64(patchBase64);
                
                const finalCanvas = document.createElement('canvas');
                finalCanvas.width = naturalWidth;
                finalCanvas.height = naturalHeight;
                const ctx = finalCanvas.getContext('2d')!;

                // 1. Draw original image
                ctx.drawImage(baseLayer.image, 0, 0);

                // 2. Draw inpainted patch over the old text area.
                ctx.drawImage(inpaintedPatch, region.bounds.x, region.bounds.y, region.bounds.width, region.bounds.height);
                
                // 3. Render the new, AI-optimized text on top
                const optimizedRegion: EnhancedTextRegion = {
                    ...region,
                    style: {
                        ...region.style,
                        ...optimalParams.optimalStyle,
                        textAlign: optimalParams.justification,
                    }
                };
                renderEnhancedText(ctx, optimalParams.optimalText, optimizedRegion);

                // 4. Create a new layer with the result
                const finalImage = await imageFromBase64(finalCanvas.toDataURL('image/png'));
                this.addLayer(finalImage, `Text: ${newText.substring(0, 20)}...`);

                this.addNotification('success', 'Text replaced successfully on a new layer.');
                
                // 5. Reset state
                this.setTextConfig({ selectedRegion: null, newText: '', originalText: '' });

            } catch(e) {
                this.addNotification('error', 'Failed to apply generated text.');
                console.error(e);
            }
        },
        error: (err) => {
            console.error('Text replacement failed', err);
            this.addNotification('error', 'Text replacement request failed.');
        }
    });
  }

  selectSubject(): void {
    const baseLayer = this.layers()[0];
    if (!baseLayer) return;

    this.loadingState.startLoading('Identifying main subject...');
    const imageDataUrl = getBase64FromImage(baseLayer.image);

    this.geminiService.selectSubject(imageDataUrl).pipe(
        finalize(() => this.loadingState.stopLoading())
    ).subscribe({
        next: (polygon) => {
            if (polygon && polygon.length > 2) {
                this._subjectPolygon.set(polygon);
                this._selectionBounds.set(null); // Clear bounds if polygon is set
                this.addNotification('success', 'Subject outline created.');
            } else {
                this.addNotification('warning', 'Could not identify a clear subject.');
            }
        },
        error: (err) => {
            console.error('Subject selection failed', err);
            this.addNotification('error', 'Failed to identify the main subject.');
        }
    });
  }

  performGenerativeFill(prompt: string): void {
    const baseLayer = this.layers()[0];
    const selectionBounds = this.selectionBounds();
    const subjectPolygon = this.subjectPolygon();

    if (!baseLayer || (!selectionBounds && !subjectPolygon)) {
        this.addNotification('error', 'Please select an area or detect a subject first.');
        return;
    }

    this.loadingState.startLoading('Performing generative fill...');
    const { naturalWidth, naturalHeight } = baseLayer.image;
    const imageDataUrl = getBase64FromImage(baseLayer.image);
    const maskDataUrl = selectionBounds
        ? createMaskFromPolygon(naturalWidth, naturalHeight, [
            { x: selectionBounds.x, y: selectionBounds.y },
            { x: selectionBounds.x + selectionBounds.width, y: selectionBounds.y },
            { x: selectionBounds.x + selectionBounds.width, y: selectionBounds.y + selectionBounds.height },
            { x: selectionBounds.x, y: selectionBounds.y + selectionBounds.height },
        ])
        : createMaskFromPolygon(naturalWidth, naturalHeight, subjectPolygon!);

    this.geminiService.generativeFill(imageDataUrl, maskDataUrl, prompt).pipe(
        finalize(() => this.loadingState.stopLoading())
    ).subscribe({
        next: async (patchBase64) => {
            try {
                const patchImage = await imageFromBase64(patchBase64);
                this.addLayer(patchImage, `Fill: ${prompt.substring(0, 20)}...`);
                this.addNotification('success', 'Generative fill applied as a new layer.');
                this.setSelectionBounds(null);
                this._subjectPolygon.set(null);
            } catch (e) {
                this.addNotification('error', 'Failed to apply generated image patch.');
                console.error(e);
            }
        },
        error: (err) => {
            console.error('Generative fill failed', err);
            this.addNotification('error', 'Generative fill request failed.');
        }
    });
  }
  
  performImageGeneration(prompt: string, aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4'): void {
    this.loadingState.startLoading('Generating image with AI...');

    this.geminiService.generateImage(prompt, aspectRatio).pipe(
      finalize(() => this.loadingState.stopLoading())
    ).subscribe({
      next: async (imageBase64) => {
        try {
          const newImage = await imageFromBase64(imageBase64);
          this.addLayer(newImage, `AI: ${prompt.substring(0, 20)}...`);
          this.addNotification('success', 'Image generated and added as a new layer.');
        } catch (e) {
          this.addNotification('error', 'Failed to load the generated image.');
          console.error(e);
        }
      },
      error: (err) => {
        console.error('Image generation failed', err);
        this.addNotification('error', 'Image generation request failed.');
      }
    });
  }

  async applyEffectToActiveLayer(effect: Effect): Promise<void> {
    const layer = this.activeLayer();
    if (!layer) {
        this.addNotification('warning', 'Please select a layer to apply an effect.');
        return;
    }

    this.loadingState.startLoading(`Applying ${effect.type}...`);
    try {
        const newImage = await this.effectsService.applyEffect(layer.image, effect);
        this.addLayer(newImage, `${layer.name} (${effect.type})`);
        this.addNotification('success', `${effect.type} applied as a new layer.`);
    } catch (e) {
        console.error('Failed to apply effect', e);
        this.addNotification('error', 'Could not apply the effect.');
    } finally {
        this.loadingState.stopLoading();
    }
  }
  
  addManualRegion(bounds: Bounds): void {
    this.setSelectionBounds(bounds);
    this.addNotification('info', 'Selection area created.');
  }

  private createThumbnail(image: HTMLImageElement, size = 64): string {
    const canvas = document.createElement('canvas');
    const aspect = image.naturalWidth / image.naturalHeight;
    canvas.width = size;
    canvas.height = size / aspect;
    if (aspect < 1) {
        canvas.width = size * aspect;
        canvas.height = size;
    }
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg');
  }

  // History Methods
  private restoreLayersFromHistory(layers: Layer[]): void {
      const clonedLayers = layers.map(layer => ({ ...layer }));
      this._layers.set(clonedLayers);
  }

  undo(): void {
      const state = this.historyService.undo();
      if (state) {
          this.restoreLayersFromHistory(state.layers);
          this.addNotification('info', `Undo: ${state.actionName}`);
      }
  }

  redo(): void {
      const state = this.historyService.redo();
      if (state) {
          this.restoreLayersFromHistory(state.layers);
          this.addNotification('info', `Redo: ${state.actionName}`);
      }
  }
  
  revertToHistoryState(index: number): void {
      const state = this.historyService.revertToState(index);
      if (state) {
          this.restoreLayersFromHistory(state.layers);
          this.addNotification('info', `Reverted to: ${state.actionName}`);
      }
  }
}