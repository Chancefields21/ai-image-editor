import { Injectable } from '@angular/core';
import { Effect, DropShadowEffect, GlowEffect } from '../types';
import { imageFromBase64 } from '../utils/image-edit';

@Injectable({
  providedIn: 'root'
})
export class EffectsService {
  async applyEffect(image: HTMLImageElement, effect: Effect): Promise<HTMLImageElement> {
    const canvas = document.createElement('canvas');
    const padding = (effect.type === 'drop-shadow' 
      ? Math.max(Math.abs(effect.offsetX), Math.abs(effect.offsetY)) + effect.blur
      : effect.blur) * 2;
    
    canvas.width = image.naturalWidth + padding * 2;
    canvas.height = image.naturalHeight + padding * 2;
    const ctx = canvas.getContext('2d')!;
    
    if (effect.type === 'drop-shadow') {
      this.applyDropShadow(ctx, image, effect, padding);
    } else if (effect.type === 'glow') {
      this.applyGlow(ctx, image, effect, padding);
    }
    
    return imageFromBase64(canvas.toDataURL('image/png'));
  }

  private applyDropShadow(
    ctx: CanvasRenderingContext2D, 
    image: HTMLImageElement, 
    params: DropShadowEffect, 
    padding: number
  ) {
    ctx.shadowColor = params.color;
    ctx.shadowOffsetX = params.offsetX;
    ctx.shadowOffsetY = params.offsetY;
    ctx.shadowBlur = params.blur;
    ctx.drawImage(image, padding, padding);
  }

  private applyGlow(
    ctx: CanvasRenderingContext2D, 
    image: HTMLImageElement, 
    params: GlowEffect, 
    padding: number
  ) {
    ctx.shadowColor = params.color;
    ctx.shadowBlur = params.blur;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    
    const passes = Math.max(1, Math.round(params.intensity * 5));
    ctx.globalAlpha = 1 / passes;
    
    for (let i = 0; i < passes; i++) {
        ctx.drawImage(image, padding, padding);
    }
    
    ctx.globalAlpha = 1;
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.drawImage(image, padding, padding);
  }
}
