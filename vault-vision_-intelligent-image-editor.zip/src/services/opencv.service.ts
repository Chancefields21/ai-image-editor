import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OpenCVService {
  private loadingPromise: Promise<void> | null = null;

  ensureLoaded(): Promise<void> {
    if (this.loadingPromise) {
      return this.loadingPromise;
    }

    this.loadingPromise = new Promise<void>((resolve, reject) => {
      // Check if OpenCV is already available
      const checkCv = () => {
        if ((window as any).cv?.Mat) {
          resolve();
          return true;
        }
        return false;
      };

      if (checkCv()) {
        return;
      }

      // OpenCV.js script uses Module.onRuntimeInitialized to signal readiness.
      (window as any).Module = {
        onRuntimeInitialized: () => {
          if (!checkCv()) {
            reject(new Error("OpenCV runtime initialized but `cv` is not on the window object."));
          }
        }
      };

      const script = document.querySelector('script[src*="opencv.js"]');
      if (!script) {
        reject(new Error("OpenCV.js script not found in document."));
      }
    });

    return this.loadingPromise;
  }
}
