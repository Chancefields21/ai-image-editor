import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoadingStateService {
  private readonly _isLoading = signal(false);
  private readonly _loadingMessage = signal('');

  readonly isLoading = this._isLoading.asReadonly();
  readonly loadingMessage = this._loadingMessage.asReadonly();

  startLoading(message: string): void {
    this._isLoading.set(true);
    this._loadingMessage.set(message);
  }

  stopLoading(): void {
    this._isLoading.set(false);
    this._loadingMessage.set('');
  }
}
