import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  // This service is currently a stub.
  // It could be used to manage application-wide dialogs/modals in the future.
  constructor() { }
}
