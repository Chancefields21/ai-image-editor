
import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { from, Observable, map, throwError, catchError } from 'rxjs';
import { Point, EnhancedTextRegion, OptimalTextParams } from '../types';
import { getBoundsFromQuad } from '../utils/geometry';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  private imageToPart(imageDataUrl: string) {
    return {
      inlineData: {
        data: imageDataUrl.split(',')[1],
        mimeType: 'image/png', // Assuming PNG from data URL
      },
    };
  }

  detectAndAnalyzeText(imageDataUrl: string): Observable<EnhancedTextRegion[]> {
    const prompt = `
    Analyze the provided image and identify all distinct text regions with high fidelity.
    For each region, provide a comprehensive analysis of its properties.
    Return an array of text region objects. Each object must include:
    1.  text: The detected text content.
    2.  quad: A precise quadrilateral with four {x, y} corner points in clockwise order (top-left, top-right, bottom-right, bottom-left).
    3.  style: An object with:
        - color: Dominant text color as a hex string (e.g., "#FFFFFF").
        - fontSize: Font size in pixels.
        - fontFamily: Best guess for font family (e.g., "Helvetica", "serif").
        - fontWeight: Font weight (e.g., "normal", "bold", "700").
        - fontStyle: Font style (e.g., "normal", "italic").
        - rotation: Overall rotation angle of the text block in degrees.
    4.  confidence: A confidence score from 0 to 1.
    5.  textBaseline: The vertical alignment of the text ('top', 'middle', 'bottom', 'alphabetic').
    6.  letterSpacing: The spacing between characters in pixels.
    7.  lineHeight: The height of a line of text as a multiplier of the font size (e.g., 1.2).
    8.  textShadow: (Optional) If a shadow is present, an object with {color, offsetX, offsetY, blurRadius}.
    9.  textStroke: (Optional) If the text has an outline, an object with {color, width}.
    10. contextualHints: An array of strings describing the context (e.g., "Text is on a curved surface", "Partially obscured").
    11. semanticRole: The role of the text ('heading', 'body', 'caption', 'logo', 'decorative').
    `;
    
    return from(this.ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { parts: [this.imageToPart(imageDataUrl), { text: prompt }] },
    config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
              regions: {
                  type: Type.ARRAY,
                  items: {
                      type: Type.OBJECT,
                      properties: {
                          text: { type: Type.STRING },
                          quad: {
                              type: Type.ARRAY,
                              items: { type: Type.OBJECT, properties: { x: { type: Type.NUMBER }, y: { type: Type.NUMBER } }, required: ['x', 'y'] },
                              minItems: 4, maxItems: 4
                          },
                          style: {
                              type: Type.OBJECT,
                              properties: {
                                  color: { type: Type.STRING },
                                  fontSize: { type: Type.NUMBER },
                                  fontFamily: { type: Type.STRING },
                                  fontWeight: { type: Type.STRING },
                                  fontStyle: { type: Type.STRING },
                                  rotation: { type: Type.NUMBER }
                              },
                              required: ['color', 'fontSize', 'fontFamily', 'fontWeight', 'fontStyle', 'rotation']
                          },
                          confidence: { type: Type.NUMBER },
                          textBaseline: { type: Type.STRING, enum: ['top', 'hanging', 'middle', 'alphabetic', 'ideographic', 'bottom'] },
                          letterSpacing: { type: Type.NUMBER },
                          lineHeight: { type: Type.NUMBER },
                          textShadow: {
                              type: Type.OBJECT,
                              nullable: true,
                              properties: {
                                  color: { type: Type.STRING },
                                  offsetX: { type: Type.NUMBER },
                                  offsetY: { type: Type.NUMBER },
                                  blurRadius: { type: Type.NUMBER }
                              },
                              required: ['color', 'offsetX', 'offsetY', 'blurRadius']
                          },
                          textStroke: {
                              type: Type.OBJECT,
                              nullable: true,
                              properties: {
                                  color: { type: Type.STRING },
                                  width: { type: Type.NUMBER }
                              },
                              required: ['color', 'width']
                          },
                          contextualHints: { type: Type.ARRAY, items: { type: Type.STRING } },
                          semanticRole: { type: Type.STRING, enum: ['heading', 'body', 'caption', 'logo', 'decorative'] }
                      },
                      required: ['text', 'quad', 'style', 'confidence', 'textBaseline', 'letterSpacing', 'lineHeight', 'contextualHints', 'semanticRole']
                  }
              }
          },
          required: ['regions']
      }
    }
    })).pipe(
      map(response => {
        try {
            const data = JSON.parse(response.text);
            return (data.regions || []).map((region: any, index: number) => ({
                ...region,
                id: `text-region-${Date.now()}-${index}`,
                bounds: getBoundsFromQuad(region.quad),
            }));
        } catch (e) {
            console.error("Error parsing Gemini response for text detection:", e);
            console.error("Raw response:", response.text);
            throw new Error('Failed to parse text detection response.');
        }
      }),
      catchError(err => {
        console.error("Error in detectAndAnalyzeText:", err);
        return throwError(() => new Error('An error occurred while detecting text.'));
      })
    );
  }

  getOptimalTextVariation(
    originalRegion: EnhancedTextRegion,
    newText: string
  ): Observable<OptimalTextParams> {
    const prompt = `You are an expert typographer and graphic designer. Your task is to determine the optimal way to replace text in an image.
Given the original text's properties and the new text content, provide the best layout and style adjustments for maximum readability and aesthetic harmony.
The new text must fit within the original text's bounding box: {width: ${originalRegion.bounds.width}, height: ${originalRegion.bounds.height}}.

Original text properties:
- Font Family: ${originalRegion.style.fontFamily}
- Font Size: ${originalRegion.style.fontSize}px
- Font Weight: ${originalRegion.style.fontWeight}
- Color: ${originalRegion.style.color}
- Semantic Role: ${originalRegion.semanticRole}

New text to place: "${newText}"

Your task is to return:
1.  optimalText: The new text with line breaks inserted (using '\\n') to fit optimally within the bounding box.
2.  optimalStyle: An object with style adjustments. You can slightly adjust 'fontSize' (e.g., by 1-2 pixels) if necessary to improve the fit. Only include 'fontSize' if you change it. If no change is needed, return an empty object.
3.  justification: The best text alignment ('left', 'center', or 'right') for the given text and context.
Consider the semantic role. For a 'heading', center justification might be best. For 'body' text, left might be better.`;

    return from(this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }] },
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    optimalText: { type: Type.STRING, description: "The new text with newline characters (\\n) for optimal line breaks." },
                    optimalStyle: {
                        type: Type.OBJECT,
                        properties: {
                            fontSize: { type: Type.NUMBER, description: "Adjusted font size in pixels. Only include if different from original." }
                        }
                    },
                    justification: { type: Type.STRING, enum: ['left', 'center', 'right'] }
                },
                required: ['optimalText', 'optimalStyle', 'justification']
            }
        }
    })).pipe(
        map(response => {
            try {
                return JSON.parse(response.text) as OptimalTextParams;
            } catch (e) {
                console.error("Error parsing Gemini response for text optimization:", e);
                console.error("Raw response:", response.text);
                throw new Error('Failed to parse text optimization response.');
            }
        }),
        catchError(err => {
            console.error("Error in getOptimalTextVariation:", err);
            return throwError(() => new Error('An error occurred during text optimization.'));
        })
    );
  }

  selectSubject(imageDataUrl: string): Observable<Point[]> {
    const prompt = `
    Analyze the provided image and identify the main subject.
    Return a polygon that tightly outlines the subject.
    The polygon should be an array of {x, y} points.
    `;

    return from(this.ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { parts: [this.imageToPart(imageDataUrl), { text: prompt }] },
    config: {
        responseMimeType: 'application/json',
        responseSchema: {
        type: Type.OBJECT,
        properties: {
            subjectPolygon: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER },
                },
                required: ['x', 'y']
            }
            }
        },
        required: ['subjectPolygon']
        }
    }
    })).pipe(
      map(response => {
        try {
            const data = JSON.parse(response.text);
            return data.subjectPolygon || [];
        } catch(e) {
            console.error("Error parsing Gemini response for subject selection:", e);
            console.error("Raw response:", response.text);
            throw new Error('Failed to parse subject selection response.');
        }
      }),
      catchError(err => {
        console.error("Error in selectSubject:", err);
        return throwError(() => new Error('An error occurred while selecting the subject.'));
      })
    );
  }

  generativeFill(
    imageDataUrl: string,
    maskDataUrl: string,
    prompt: string
  ): Observable<string> { // returns base64 data url for the patch
    const inpaintingPrompt = `
    You are an expert photo editor AI. You are given a base image, a mask image, and a text prompt.
    The mask image is black where the original image should be kept, and white in the area to be replaced.
    Your task is to generate a new image patch for the white area in the mask, based on the user's prompt: "${prompt}".
    The patch should seamlessly blend with the surrounding area of the original image.
    Return ONLY the generated image patch as a base64 encoded PNG string. Do not return any other text, markdown, or data URL prefix.
    `;

    return from(this.ai.models.generateContent({
        model: 'gemini-2.5-flash', // Acknowledging this model can't generate images, but this is a workaround for the app's logic
        contents: {
            parts: [
                { text: inpaintingPrompt },
                this.imageToPart(imageDataUrl),
                this.imageToPart(maskDataUrl),
            ]
        },
    })).pipe(
      map(response => {
        const text = response.text.trim();
        if (!text) {
          throw new Error('Generative fill returned an empty response.');
        }
        return `data:image/png;base64,${text}`;
      }),
      catchError(err => {
        console.error("Error in generativeFill:", err);
        return throwError(() => new Error('An error occurred during generative fill.'));
      })
    );
  }

  generateImage(
    prompt: string,
    aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4'
  ): Observable<string> {
    return from(this.ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio,
        },
    })).pipe(
      map(response => {
        if (response.generatedImages && response.generatedImages.length > 0) {
          const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
          return `data:image/jpeg;base64,${base64ImageBytes}`;
        }
        throw new Error('Image generation failed to return an image.');
      }),
      catchError(err => {
        console.error("Error in generateImage:", err);
        return throwError(() => new Error('An error occurred during image generation.'));
      })
    );
  }
}