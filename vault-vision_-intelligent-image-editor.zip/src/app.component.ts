
import { Component, ChangeDetectionStrategy, inject, signal, viewChild, ElementRef, computed, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorStateService } from './services/editor-state.service';

// Import all components
import { TopMenuComponent } from './components/top-menu/top-menu.component';
import { ToolbarComponent } from './components/toolbar/toolbar.component';
import { CanvasWorkspaceComponent } from './components/canvas-workspace/canvas-workspace.component';
import { RightPanelComponent } from './components/right-panel/right-panel.component';
import { WelcomeScreenComponent } from './components/welcome-screen/welcome-screen.component';
import { NotificationContainerComponent } from './components/notification-container/notification-container.component';
import { LoadingBarComponent } from './components/loading-bar/loading-bar.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    TopMenuComponent,
    ToolbarComponent,
    CanvasWorkspaceComponent,
    RightPanelComponent,
    WelcomeScreenComponent,
    NotificationContainerComponent,
    LoadingBarComponent,
  ],
  template: `
    <div class="h-screen w-screen bg-[var(--app-bg)] text-gray-200 flex flex-col font-sans antialiased overflow-hidden">
      @if (hasImage()) {
        <app-top-menu 
          (openFile)="triggerFileInput()"
          (closeFile)="closeProject()"
        />
        <main class="flex flex-grow overflow-hidden">
          <app-toolbar />
          <app-canvas-workspace class="flex-grow" />
          <app-right-panel />
        </main>
      } @else {
        <app-welcome-screen class="flex-grow" (imageUploaded)="onImageUploaded($event)" />
      }

      <app-notification-container [notifications]="notifications()" />
      <app-loading-bar />
    </div>
    <input #fileInput type="file" class="hidden" (change)="onFileSelected($event)" accept="image/*" />
  `,
  styles: [`
    :host {
      --app-bg: #1e1e1e;
      --charcoal-bg: #2a2a2a;
      --border-color: #404040;
      --gold-text: #fde047;
      --gold-gradient: linear-gradient(to right, #fde047, #f59e0b);
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  private editorState = inject(EditorStateService);
  fileInputRef = viewChild.required<ElementRef<HTMLInputElement>>('fileInput');

  hasImage = computed(() => this.editorState.layers().length > 0);
  readonly notifications = this.editorState.notifications;

  onImageUploaded(image: HTMLImageElement): void {
    this.editorState.setInitialImage(image);
  }

  triggerFileInput(): void {
    this.fileInputRef().nativeElement.value = ''; // Reset to allow same file selection
    this.fileInputRef().nativeElement.click();
  }

  closeProject(): void {
    this.editorState.closeImage();
  }

  onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        this.editorState.addNotification('error', 'Please upload a valid image file.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>) => {
        const img = new Image();
        img.onload = () => {
          this.onImageUploaded(img);
        };
        img.onerror = () => {
            this.editorState.addNotification('error', 'Could not load the image file.');
        }
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  @HostListener('document:keydown', ['$event'])
  handleGlobalKeyboardShortcuts(event: KeyboardEvent) {
    // Ignore shortcuts if user is typing in an input field
    const target = event.target as HTMLElement;
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) {
      return;
    }

    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const modifierKey = isMac ? event.metaKey : event.ctrlKey;

    if (modifierKey) {
      if (event.key === 'z') {
        event.preventDefault();
        if (event.shiftKey) {
          this.editorState.redo();
        } else {
          this.editorState.undo();
        }
      } else if (event.key === 'y') {
        event.preventDefault();
        this.editorState.redo();
      }
    }
  }
}
